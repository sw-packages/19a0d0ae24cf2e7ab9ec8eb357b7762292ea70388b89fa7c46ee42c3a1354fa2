#pragma once

namespace flecs {

struct term;
struct term_builder;

}
